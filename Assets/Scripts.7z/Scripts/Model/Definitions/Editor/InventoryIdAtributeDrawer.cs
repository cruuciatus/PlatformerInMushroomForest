using UnityEditor;
using UnityEngine;

public class InventoryIdAtributeDrawer : PropertyDrawer
{
    //public override void OnGUI
}
