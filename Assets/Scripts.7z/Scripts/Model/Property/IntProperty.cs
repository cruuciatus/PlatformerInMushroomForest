using System;

[Serializable]
public class IntProperty : ObservableProperty<int>
{
    
}
