using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class StateLoadGame
{

    public static bool IsBegin;
    public static string CurrentCheckPoint = "";
}
